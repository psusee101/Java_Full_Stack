package spring_mvc.spring_boot_mvs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvsApplication.class, args);
	}

}
